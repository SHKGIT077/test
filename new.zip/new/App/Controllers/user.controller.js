"use strict";
const express = require("express");

const { User_model } = require('../Models/user.model')
const { validationResult } = require('express-validator')
const mongoose = require('mongoose')
const ObjectId = mongoose.Types.ObjectId;

// Product CLASS
class Employee {
    async AddEmployee(req, res) {
        try {
           
                // Company Information
                const user = new User_model({
                    
                });
                await user.save();

            
        }
        catch (error) {
            res.send({ msg: "Error=>", error })
        }

    }

    // async GetEmployee(req, res) {



    //     const docs = await EmployeeModal.aggregate([

    //         { $match: {  _id:ObjectId(req.params.id)} }
    //         ,
    //         {
    //             $lookup: {
    //                 from: "company_informations",
    //                 localField: "_id",
    //                 foreignField: "userid",
    //                 as: "result"
    //             }
    //         },
    //         {
    //             $lookup: {
    //                 from: "account_informations",
    //                 localField: "_id",
    //                 foreignField: "userid",
    //                 as: "result1"
    //             }
    //         },
    //         {
    //             $lookup: {
    //                 from: "financial_informations",
    //                 localField: "_id",
    //                 foreignField: "userid",
    //                 as: "result2"
    //             }
    //         }
    //     ])
    //     // console.log("docs", docs)
    //     res.send({ msg: docs })
    // }


}


module.exports = new Employee();